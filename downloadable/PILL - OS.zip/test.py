import tkinter as tk
import os
import time

CONFIG_FILE = "test.p"
ICON_PATH = "icon.png"
FILE_OUTPUT_FOLDER = "File"
BUILD_ID = "Indev-1"

def is_zip_context():
    path_parts = os.path.abspath(__file__).lower().split(os.sep)
    return any(part.endswith(".zip") for part in path_parts)

def load_config():
    config = {"name": "Pill Console", "commands": []}
    if not os.path.exists(CONFIG_FILE):
        return config
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                key, val = line.split("=", 1)
                if key.strip() == "name":
                    config["name"] = val.strip()
                else:
                    config["commands"].append((key.strip(), val.strip()))
    return config

config = load_config()

tmp = tk.Tk()
screen_width = tmp.winfo_screenwidth()
screen_height = tmp.winfo_screenheight()
tmp.destroy()

# Interface d’erreur ZIP
if is_zip_context():
    error_root = tk.Tk()
    error_root.geometry("600x160+200+200")
    error_root.configure(bg="#1e1e1e")
    error_root.overrideredirect(True)

    try:
        icon = tk.PhotoImage(file=ICON_PATH)
        error_root.iconphoto(False, icon)
    except:
        icon = None

    def close_error():
        for i in range(10, -1, -1):
            error_root.attributes("-alpha", i / 10)
            error_root.update()
            time.sleep(0.02)
        error_root.destroy()

    title_bar = tk.Frame(error_root, bg="#2d2d2d", height=32)
    title_bar.pack(fill=tk.X, side=tk.TOP)

    if icon:
        icon_label = tk.Label(title_bar, image=icon, bg="#2d2d2d")
        icon_label.pack(side=tk.LEFT, padx=(4, 0), pady=2)

    title_label = tk.Label(title_bar, text=f"{config['name']} [ERREUR ZIP]",
                           fg="white", bg="#2d2d2d")
    title_label.pack(side=tk.LEFT, padx=(8, 0))

    close_btn = tk.Label(title_bar, text="✕", font=("Arial", 12, "bold"),
                         bg="#8b0000", fg="white", padx=10, pady=2, cursor="hand2")
    close_btn.pack(side=tk.RIGHT, padx=8, pady=2)
    close_btn.bind("<Button-1>", lambda e: close_error())
    close_btn.bind("<Enter>", lambda e: close_btn.config(bg="#ff1a1a"))
    close_btn.bind("<Leave>", lambda e: close_btn.config(bg="#8b0000"))

    frame = tk.Frame(error_root, bg="#2d2d2d", bd=2, relief="sunken")
    frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

    label = tk.Label(frame, text="[!] Console inutilisable dans un .zip\nDécompresse avant de lancer.",
                     fg="#ff5c5c", bg="#2d2d2d", justify="center")
    label.pack(expand=True, pady=20)

    error_root.mainloop()
    exit()

# Interface principale
root = tk.Tk()
root.overrideredirect(True)
root.geometry(f"{screen_width}x{screen_height}")
root.configure(bg="#1e1e1e")

try:
    icon = tk.PhotoImage(file=ICON_PATH)
    root.iconphoto(False, icon)
except:
    icon = None

theme_colors = {
    "dark": {"bg": "#1e1e1e", "fg": "white", "frame": "#2d2d2d"},
    "light": {"bg": "#dddddd", "fg": "#000000", "frame": "#bbbbbb"}
}
current_theme = "dark"

def apply_theme(name):
    global current_theme
    current_theme = name
    colors = theme_colors[name]
    root.configure(bg=colors["bg"])
    top_bar.configure(bg=colors["frame"])
    title_label.configure(bg=colors["frame"], fg=colors["fg"])
    if icon:
        icon_label.configure(bg=colors["frame"])
    close_btn.configure(bg="#8b0000" if name == "dark" else "#d90000", fg="white")
    output_frame.configure(bg=colors["frame"])
    output_text.configure(bg=colors["bg"], fg=colors["fg"])
    entry_frame.configure(bg=colors["frame"])
    entry.configure(bg=colors["bg"], fg=colors["fg"], insertbackground=colors["fg"])
    footer_left.configure(bg=colors["bg"], fg="gray")
    footer_right.configure(bg=colors["bg"], fg="gray")

def close_console():
    root.destroy()

top_bar = tk.Frame(root, height=32, bg="#2d2d2d")
top_bar.pack(fill=tk.X, side=tk.TOP)

if icon:
    icon_label = tk.Label(top_bar, image=icon, bg="#2d2d2d")
    icon_label.pack(side=tk.LEFT, padx=(4, 0), pady=2)

title_label = tk.Label(top_bar, text=f"{config['name']} [BUILD {BUILD_ID}]",
                       fg="white", bg="#2d2d2d")
title_label.pack(side=tk.LEFT, padx=(8, 0))

# Fermer stylé
close_btn = tk.Label(top_bar, text="✕", font=("Arial", 12, "bold"),
                     bg="#8b0000", fg="white", padx=10, pady=2, cursor="hand2", bd=2, relief="raised")
close_btn.pack(side=tk.RIGHT, padx=10, pady=2)
def hover_close_on(e): close_btn.config(bg="#ff1a1a", relief="sunken")
def hover_close_off(e): close_btn.config(bg="#8b0000", relief="raised")
close_btn.bind("<Button-1>", lambda e: close_console())
close_btn.bind("<Enter>", hover_close_on)
close_btn.bind("<Leave>", hover_close_off)

theme_frame = tk.Frame(top_bar, bg="#2d2d2d")
theme_frame.pack(side=tk.RIGHT, padx=10)

dark_img = tk.PhotoImage(file="Themes/dark_theme.png")
light_img = tk.PhotoImage(file="Themes/light_theme.png")

def style_button(btn):
    btn.config(bd=2, relief="raised", bg="#3a3a3a", activebackground="#5a5a5a", cursor="hand2")
    btn.bind("<Enter>", lambda e: btn.config(relief="sunken", bg="#5a5a5a"))
    btn.bind("<Leave>", lambda e: btn.config(relief="raised", bg="#3a3a3a"))

dark_button = tk.Button(theme_frame, image=dark_img, command=lambda: apply_theme("dark"))
light_button = tk.Button(theme_frame, image=light_img, command=lambda: apply_theme("light"))
style_button(dark_button)
style_button(light_button)
dark_button.pack(side=tk.LEFT, padx=2)
light_button.pack(side=tk.LEFT, padx=2)

output_frame = tk.Frame(root, bg="#2d2d2d", bd=2, relief="sunken")
output_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

output_text = tk.Text(output_frame, bg="#1e1e1e", fg="white", wrap="word", bd=0)
output_text.pack(fill=tk.BOTH, expand=True)

output_text.tag_config("cmd", foreground="#5cacee")
output_text.tag_config("info", foreground="#ff8080")
output_text.tag_config("error", foreground="#ff5c5c")
output_text.tag_config("success", foreground="#7CFC00")
output_text.tag_config("run", foreground="#b0b0b0")

entry_frame = tk.Frame(root, bg="#2d2d2d", bd=2, relief="sunken")
entry_frame.pack(fill=tk.X, padx=10, pady=(0, 10))

entry = tk.Entry(entry_frame, bg="#1e1e1e", fg="white", insertbackground="white")
entry.pack(fill=tk.X, padx=5, pady=5)

def write(text, tag=None):
    output_text.configure(state="normal")
    output_text.insert(tk.END, text + "\n", tag)
    output_text.configure(state="disabled")
    output_text.see(tk.END)

def handle_command(event=None):
    cmd = entry.get().strip()
    if not cmd:
        return
    write("> " + cmd, "run")
    args = cmd.split()
    if args[0] == "/exit":
        write("Fermeture...", "success")
        root.after(500, root.destroy)
    elif args[0] == "/createfile":
        if len(args) != 3 or not args[2].startswith("."):
            write("Utilisation: /createfile {nom} {.ext}", "error")
        else:
            os.makedirs(FILE_OUTPUT_FOLDER, exist_ok=True)
            filepath = os.path.join(FILE_OUTPUT_FOLDER, args[1] + args[2])
            try:
                with open(filepath, "w", encoding="utf-8") as f:
                    f.write("")
                write(f"Fichier créé: {filepath}", "success")
            except Exception as e:
                write(f"Erreur: {e}", "error")
    elif args[0] == "/listfile":
        if not os.path.exists(FILE_OUTPUT_FOLDER):
            write("Dossier 'File' introuvable.", "error")
        else:
            files = os.listdir(FILE_OUTPUT_FOLDER)
            if not files:
                write("Aucun fichier trouvé.", "error")
            else:
                write("Fichiers:", "success")
                for f in files:
                    write(" - " + f, "run")
    elif args[0] == "/deletefile":
        if len(args) != 3:
            write("Utilisation: /deletefile {nom} {.ext}", "error")
        else:
            filepath = os.path.join(FILE_OUTPUT_FOLDER, args[1] + args[2])
            if os.path.exists(filepath):
                os.remove(filepath)
                write(f"Fichier supprimé: {filepath}", "success")
            else:
                write("Fichier introuvable.", "error")
    elif args[0] == "/loadfile":
        if len(args) != 3:
            write("Utilisation: /loadfile {nom} {.ext}", "error")
        else:
            filepath = os.path.join(FILE_OUTPUT_FOLDER, args[1] + args[2])
            if os.path.exists(filepath):
                with open(filepath, "r", encoding="utf-8") as f:
                    content = f.read()
                write("Contenu du fichier:\n" + content, "run")
            else:
                write("Fichier introuvable.", "error")
    elif args[0] == "/help":
        write("/exit - Fermer La Console", "cmd")
        write("/createfile {nom} {.ext} - Créer un fichier", "cmd")
        write("/listfile - Lister les fichiers", "cmd")
        write("/deletefile {nom} {.ext} - Supprimer un fichier", "cmd")
        write("/loadfile {nom} {.ext} - Ouvrir un fichier", "cmd")
        write("/help - Affiche cette aide", "cmd")
    else:
        write("Commande inconnue.", "error")
    entry.delete(0, tk.END)

entry.bind("<Return>", handle_command)

write("Bienvenue sur la console de Pill !", "info")
write("Commandes disponibles : /help", "cmd")

footer_left = tk.Label(root, text="Indev 1.0", bg="#1e1e1e", fg="gray")
footer_left.pack(side=tk.LEFT, padx=10, pady=5)

footer_right = tk.Label(root, text="Copyright - PILL", bg="#1e1e1e", fg="gray")
footer_right.pack(side=tk.RIGHT, padx=10, pady=5)

apply_theme(current_theme)
root.mainloop()
