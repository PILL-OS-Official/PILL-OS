import tkinter as tk
import os
import time

CONFIG_FILE = "test.p"
ICON_PATH = "icon.png"
FILE_OUTPUT_FOLDER = "File"

def is_zip_context():
    path_parts = os.path.abspath(__file__).lower().split(os.sep)
    return any(part.endswith(".zip") for part in path_parts)

def load_config():
    config = {"name": "Pill Console", "commands": []}
    if not os.path.exists(CONFIG_FILE):
        return config
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                key, val = line.split("=", 1)
                if key.strip() == "name":
                    config["name"] = val.strip()
                else:
                    config["commands"].append((key.strip(), val.strip()))
    return config

config = load_config()
BUILD_ID = "Indev-1"

# Erreur si dans un .zip
if is_zip_context():
    error_root = tk.Tk()
    error_root.geometry("600x160+200+200")
    error_root.configure(bg="#1e1e1e")
    error_root.overrideredirect(True)

    try:
        icon = tk.PhotoImage(file=ICON_PATH)
        error_root.iconphoto(False, icon)
    except:
        icon = None

    def close_error():
        for i in range(10, -1, -1):
            error_root.attributes("-alpha", i / 10)
            error_root.update()
            time.sleep(0.02)
        error_root.destroy()

    title_bar = tk.Frame(error_root, bg="#2d2d2d", height=32)
    title_bar.pack(fill=tk.X, side=tk.TOP)

    if icon:
        icon_label = tk.Label(title_bar, image=icon, bg="#2d2d2d")
        icon_label.pack(side=tk.LEFT, padx=(4, 0), pady=2)

    title_label = tk.Label(title_bar, text=f"{config['name']} [ERREUR ZIP]",
                           fg="white", bg="#2d2d2d", font=("JetBrains Mono", 10, "bold"))
    title_label.pack(side=tk.LEFT, padx=(8, 0))

    def start_move(event):
        error_root.x = event.x
        error_root.y = event.y

    def do_move(event):
        x = error_root.winfo_x() + (event.x - error_root.x)
        y = error_root.winfo_y() + (event.y - error_root.y)
        error_root.geometry(f"+{x}+{y}")

    title_bar.bind("<Button-1>", start_move)
    title_bar.bind("<B1-Motion>", do_move)

    close_btn_frame = tk.Frame(title_bar, bg="#3b0000", bd=1, relief="raised")
    close_btn_frame.pack(side=tk.RIGHT, padx=(4, 10), pady=2)

    close_btn = tk.Label(close_btn_frame, text="Fermer", bg="#8b0000", fg="white",
                         font=("JetBrains Mono", 9, "bold"), padx=10, pady=2, cursor="hand2")
    close_btn.pack()
    close_btn.bind("<Button-1>", lambda e: close_error())
    close_btn.bind("<Enter>", lambda e: close_btn.config(bg="#ff1a1a"))
    close_btn.bind("<Leave>", lambda e: close_btn.config(bg="#8b0000"))

    frame = tk.Frame(error_root, bg="#2d2d2d", bd=2, relief="sunken")
    frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

    label = tk.Label(frame, text="[!] Vous ne pouvez pas utiliser la console dans un dossier .zip !\n"
                                 "Merci de le décompresser avant de lancer.",
                     fg="#ff5c5c", bg="#2d2d2d", font=("JetBrains Mono", 11), justify="center")
    label.pack(expand=True, pady=20)

    error_root.mainloop()
    exit()

# === Interface principale ===
root = tk.Tk()
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
root.geometry(f"{screen_width}x{screen_height}")
root.configure(bg="#1e1e1e")
root.overrideredirect(True)

try:
    icon = tk.PhotoImage(file=ICON_PATH)
    root.iconphoto(False, icon)
except:
    icon = None

def close_console():
    root.destroy()

top_bar = tk.Frame(root, bg="#2d2d2d", height=32)
top_bar.pack(fill=tk.X, side=tk.TOP)

if icon:
    icon_label = tk.Label(top_bar, image=icon, bg="#2d2d2d", bd=0)
    icon_label.pack(side=tk.LEFT, padx=(4, 0), pady=2)

title_label = tk.Label(top_bar, text=f"{config['name']} [BUILD {BUILD_ID}]",
                       fg="white", bg="#2d2d2d", font=("JetBrains Mono", 10, "bold"))
title_label.pack(side=tk.LEFT, padx=(8, 0))

def start_move(event):
    root.x = event.x
    root.y = event.y

def do_move(event):
    x = root.winfo_x() + (event.x - root.x)
    y = root.winfo_y() + (event.y - root.y)
    root.geometry(f"+{x}+{y}")

top_bar.bind("<Button-1>", start_move)
top_bar.bind("<B1-Motion>", do_move)

close_btn_frame = tk.Frame(top_bar, bg="#3b0000", bd=1, relief="raised")
close_btn_frame.pack(side=tk.RIGHT, padx=(10, 10), pady=4)

close_btn = tk.Label(close_btn_frame, text="Fermer", bg="#8b0000", fg="white",
                     font=("JetBrains Mono", 10, "bold"), padx=14, pady=4, cursor="hand2")
close_btn.pack()
close_btn.bind("<Button-1>", lambda e: close_console())
close_btn.bind("<Enter>", lambda e: close_btn.config(bg="#ff1a1a"))
close_btn.bind("<Leave>", lambda e: close_btn.config(bg="#8b0000"))

output_frame = tk.Frame(root, bg="#2d2d2d", bd=2, relief="sunken")
output_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

output_text = tk.Text(output_frame, bg="#1e1e1e", fg="white", font=("JetBrains Mono", 10), bd=0, wrap="word")
output_text.pack(fill=tk.BOTH, expand=True)
output_text.insert(tk.END, "Bienvenue sur la console de Pill !\n", "info")
output_text.insert(tk.END, "Commandes disponibles :\n", "info")
output_text.insert(tk.END, "/exit - Fermer la console\n", "cmd")
output_text.insert(tk.END, "/createfile {nom} {.ext} - Créer un fichier\n", "cmd")
output_text.insert(tk.END, "/listfile - Lister les fichiers\n", "cmd")
output_text.insert(tk.END, "/deletefile {nom} {.ext} - Supprimer un fichier\n", "cmd")
output_text.insert(tk.END, "/loadfile {nom} {.ext} - Lire un fichier\n", "cmd")
output_text.insert(tk.END, "/help - Réafficher cette aide\n", "cmd")
output_text.configure(state="disabled")

entry_frame = tk.Frame(root, bg="#2d2d2d", bd=2, relief="sunken")
entry_frame.pack(fill=tk.X, padx=10, pady=(0, 10))

entry = tk.Entry(entry_frame, bg="#1e1e1e", fg="white", insertbackground="white", font=("JetBrains Mono", 10))
entry.pack(fill=tk.X, padx=5, pady=5)

output_text.tag_config("cmd", foreground="#5cacee")
output_text.tag_config("info", foreground="#ff8080")
output_text.tag_config("error", foreground="#ff5c5c")
output_text.tag_config("success", foreground="#7CFC00")
output_text.tag_config("run", foreground="#b0b0b0")

def write(text, tag=None):
    output_text.configure(state="normal")
    output_text.insert(tk.END, text + "\n", tag)
    output_text.configure(state="disabled")
    output_text.see(tk.END)

def handle_command(event=None):
    cmd = entry.get().strip()
    if not cmd:
        return
    write("> " + cmd, "run")
    args = cmd.split()
    if args[0] == "/exit":
        write("Fermeture...", "success")
        root.after(500, root.destroy)
    elif args[0] == "/createfile":
        if len(args) != 3 or not args[2].startswith("."):
            write("Utilisation: /createfile {nom} {.ext}", "error")
        else:
            os.makedirs(FILE_OUTPUT_FOLDER, exist_ok=True)
            filepath = os.path.join(FILE_OUTPUT_FOLDER, args[1] + args[2])
            try:
                with open(filepath, "w", encoding="utf-8") as f:
                    f.write("")
                write(f"Fichier créé: {filepath}", "success")
            except Exception as e:
                write(f"Erreur: {e}", "error")
    elif args[0] == "/listfile":
        if not os.path.exists(FILE_OUTPUT_FOLDER):
            write("Dossier 'File' introuvable.", "error")
        else:
            files = os.listdir(FILE_OUTPUT_FOLDER)
            if not files:
                write("Aucun fichier trouvé.", "error")
            else:
                write("Fichiers:", "success")
                for f in files:
                    write(" - " + f, "run")
    elif args[0] == "/deletefile":
        if len(args) != 3 or not args[2].startswith("."):
            write("Utilisation: /deletefile {nom} {.ext}", "error")
        else:
            filepath = os.path.join(FILE_OUTPUT_FOLDER, args[1] + args[2])
            if os.path.exists(filepath):
                try:
                    os.remove(filepath)
                    write(f"Fichier supprimé : {filepath}", "success")
                except Exception as e:
                    write(f"Erreur lors de la suppression : {e}", "error")
            else:
                write("Fichier introuvable.", "error")
    elif args[0] == "/loadfile":
        if len(args) != 3 or not args[2].startswith("."):
            write("Utilisation: /loadfile {nom} {.ext}", "error")
        else:
            filepath = os.path.join(FILE_OUTPUT_FOLDER, args[1] + args[2])
            if os.path.exists(filepath):
                try:
                    with open(filepath, "r", encoding="utf-8") as f:
                        content = f.read()
                    write(f"Contenu de {filepath} :", "success")
                    write(content if content.strip() else "(vide)", "run")
                except Exception as e:
                    write(f"Erreur lors de l'ouverture : {e}", "error")
            else:
                write("Fichier introuvable.", "error")
    elif args[0] == "/help":
        write("/exit - Fermer la console", "cmd")
        write("/createfile {nom} {.ext} - Créer un fichier", "cmd")
        write("/listfile - Lister les fichiers", "cmd")
        write("/deletefile {nom} {.ext} - Supprimer un fichier", "cmd")
        write("/loadfile {nom} {.ext} - Lire un fichier", "cmd")
        write("/help - Réafficher cette aide", "cmd")
    else:
        write("Commande inconnue.", "error")
    entry.delete(0, tk.END)

entry.bind("<Return>", handle_command)

# Footer
footer_frame = tk.Frame(root, bg="#1e1e1e")
footer_frame.pack(fill=tk.X, side=tk.BOTTOM)

left_footer = tk.Label(footer_frame, text="Indev 1.0", fg="gray", bg="#1e1e1e", font=("JetBrains Mono", 8))
left_footer.pack(side=tk.LEFT, padx=10)

right_footer = tk.Label(footer_frame, text="Copyright - PILL", fg="gray", bg="#1e1e1e", font=("JetBrains Mono", 8))
right_footer.pack(side=tk.RIGHT, padx=10)

root.mainloop()
