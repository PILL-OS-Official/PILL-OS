import tkinter as tk
import os
import time

CONFIG_FILE = "test.p"
ICON_PATH = "icon.png"
FILE_OUTPUT_FOLDER = "File"

def is_zip_context():
    path_parts = os.path.abspath(__file__).lower().split(os.sep)
    return any(part.endswith(".zip") for part in path_parts)

def load_config():
    config = {"name": "PILL - OS", "commands": []}
    if not os.path.exists(CONFIG_FILE):
        return config
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                key, val = line.split("=", 1)
                if key.strip() == "name":
                    config["name"] = val.strip()
                else:
                    config["commands"].append((key.strip(), val.strip()))
    return config

config = load_config()
BUILD_ID = "Indev Publique"

# === Initialisation fenêtre principale ===
root = tk.Tk()
root.overrideredirect(True)

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
root.geometry(f"{screen_width}x{screen_height}+0+0")
root.configure(bg="#1e1e1e")
root.title(f"{config['name']} [{BUILD_ID}]")

# Icone
try:
    icon = tk.PhotoImage(file=ICON_PATH)
    root.iconphoto(False, icon)
except:
    icon = None

def close_console():
    root.destroy()

# === Barre du haut ===
top_bar = tk.Frame(root, bg="#2d2d2d", height=40)
top_bar.pack(fill=tk.X, side=tk.TOP)

def start_move(event):
    root.x = event.x
    root.y = event.y

def do_move(event):
    x = root.winfo_x() + (event.x - root.x)
    y = root.winfo_y() + (event.y - root.y)
    root.geometry(f"+{x}+{y}")

top_bar.bind("<Button-1>", start_move)
top_bar.bind("<B1-Motion>", do_move)

if icon:
    icon_label = tk.Label(top_bar, image=icon, bg="#2d2d2d")
    icon_label.pack(side=tk.LEFT, padx=(10, 4), pady=4)

title_label = tk.Label(top_bar, text=f"{config['name']} [{BUILD_ID}]",
                       fg="white", bg="#2d2d2d", font=("Consolas", 12, "bold"))
title_label.pack(side=tk.LEFT)

close_btn = tk.Label(top_bar, text="Fermer", bg="#8b0000", fg="white",
                     font=("Consolas", 10, "bold"), padx=12, pady=5, cursor="hand2")
close_btn.pack(side=tk.RIGHT, padx=10, pady=5)
close_btn.bind("<Button-1>", lambda e: close_console())
close_btn.bind("<Enter>", lambda e: close_btn.config(bg="#ff1a1a"))
close_btn.bind("<Leave>", lambda e: close_btn.config(bg="#8b0000"))

# === Zone d’affichage console ===
output_frame = tk.Frame(root, bg="#2d2d2d", bd=2, relief="sunken")
output_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=(10, 5))

output_text = tk.Text(output_frame, bg="#1e1e1e", fg="white",
                      font=("Consolas", 11), bd=0, wrap="word")
output_text.pack(fill=tk.BOTH, expand=True)
output_text.configure(state="disabled")

# === Zone de saisie ===
entry_frame = tk.Frame(root, bg="#2d2d2d", bd=2, relief="sunken")
entry_frame.pack(fill=tk.X, padx=20, pady=(5, 0))

entry = tk.Entry(entry_frame, bg="#1e1e1e", fg="white", insertbackground="white",
                 font=("Consolas", 11))
entry.pack(fill=tk.X, padx=10, pady=8)

# === Footer ===
footer_frame = tk.Frame(root, bg="#1e1e1e", height=24)
footer_frame.pack(fill=tk.X, side=tk.BOTTOM)

footer_left = tk.Label(footer_frame, text="Cette version de PILL - OS est en dévélopement !", bg="#1e1e1e", fg="#666",
                       font=("Consolas", 9))
footer_left.pack(side=tk.LEFT, padx=10)

footer_right = tk.Label(footer_frame, text="Copyright - PILL - OS", bg="#1e1e1e", fg="#666",
                        font=("Consolas", 9))
footer_right.pack(side=tk.RIGHT, padx=10)

# === Style des messages ===
output_text.tag_config("cmd", foreground="#5cacee")
output_text.tag_config("info", foreground="#ff8080")
output_text.tag_config("error", foreground="#ff5c5c")
output_text.tag_config("success", foreground="#7CFC00")
output_text.tag_config("run", foreground="#b0b0b0")

def write(text, tag=None):
    output_text.configure(state="normal")
    output_text.insert(tk.END, text + "\n", tag)
    output_text.configure(state="disabled")
    output_text.see(tk.END)

# === Affichage aide initiale ===
write("Bienvenue sur la console de Pill !", "info")
write("Commandes disponibles :", "info")
write("/exit - Fermer La Console", "cmd")
write("/createfile {nom} {.ext} - Créer un fichier", "cmd")
write("/listfile - Lister les fichiers", "cmd")
write("/help - Affiche cette aide", "cmd")
write("")

# === Commandes ===
def handle_command(event=None):
    cmd = entry.get().strip()
    if not cmd:
        return
    write("> " + cmd, "run")
    args = cmd.split()

    if args[0] == "/exit":
        write("Fermeture...", "success")
        root.after(500, root.destroy)

    elif args[0] == "/createfile":
        if len(args) != 3 or not args[2].startswith("."):
            write("Utilisation: /createfile {nom} {.ext}", "error")
        else:
            os.makedirs(FILE_OUTPUT_FOLDER, exist_ok=True)
            filepath = os.path.join(FILE_OUTPUT_FOLDER, args[1] + args[2])
            try:
                with open(filepath, "w", encoding="utf-8") as f:
                    f.write("")
                write(f"Fichier créé: {filepath}", "success")
            except Exception as e:
                write(f"Erreur: {e}", "error")

    elif args[0] == "/listfile":
        if not os.path.exists(FILE_OUTPUT_FOLDER):
            write("Dossier 'File' introuvable.", "error")
        else:
            files = os.listdir(FILE_OUTPUT_FOLDER)
            if not files:
                write("Aucun fichier trouvé.", "error")
            else:
                write("Fichiers:", "success")
                for f in files:
                    write(" - " + f, "run")

    elif args[0] == "/help":
        write("/exit - Fermer La Console", "cmd")
        write("/createfile {nom} {.ext} - Créer un fichier", "cmd")
        write("/listfile - Lister les fichiers", "cmd")
        write("/help - Affiche cette aide", "cmd")
    else:
        write("Commande inconnue.", "error")
    entry.delete(0, tk.END)

entry.bind("<Return>", handle_command)

# === Lancement ===
root.mainloop()
